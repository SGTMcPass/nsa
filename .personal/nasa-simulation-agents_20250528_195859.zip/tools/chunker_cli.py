#!/usr/bin/env python3
# tools/chunker_cli.py

from chunker_lib.cli import main

if __name__ == "__main__":
    main()
