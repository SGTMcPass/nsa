#!/usr/bin/env python3
#!/usr/bin/env python
from chunker_lib.cli import main

if __name__ == "__main__":
    main()
