class QdrantVectorStore(VectorStore):
    # implement add/search/save/load for Qdrant
    pass
